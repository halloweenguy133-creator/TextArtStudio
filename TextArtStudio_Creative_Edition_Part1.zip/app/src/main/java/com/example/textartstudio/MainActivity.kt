package com.example.textartstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.content.ContentValues
import android.os.Build
import android.provider.MediaStore
import android.graphics.Canvas
import android.graphics.Paint
import java.io.OutputStream
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val pickImage = 1001
    private val pickVideo = 1002
    private var source: Bitmap? = null
    private var art = ""
    private lateinit var preview: TextView
    private lateinit var widthSeek: SeekBar
    private lateinit var widthLabel: TextView
    private lateinit var invert: Switch
    private lateinit var rampSpinner: Spinner
    private lateinit var customRamp: EditText
    private lateinit var photoPanel: LinearLayout
    private lateinit var videoPanel: LinearLayout
    private lateinit var photoTab: Button
    private lateinit var videoTab: Button
    private var activeTab = 0

    private val bg = Color.rgb(12, 16, 30)
    private val panel = Color.rgb(24, 31, 53)
    private val cyan = Color.rgb(50, 205, 255)
    private val purple = Color.rgb(148, 76, 255)
    private val ramps = listOf(
        "Детальная (@%#*+=-:. )" to "@%#*+=-:. ",
        "Плотная (много оттенков)" to "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,^`. ",
        "Простая (@#S%?*+;:,. )" to "@#S%?*+;:,. ",
        "Цифровая (10)" to "10",
        "Блочная (█▓▒░ )" to "█▓▒░ ",
        "Контурная ( .:-=+*#%@)" to " .:-=+*#%@",
        "Свои символы" to "CUSTOM"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 12, 24)
        window.navigationBarColor = Color.rgb(9, 12, 24)
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; setStroke(1, Color.rgb(57, 74, 115)) }

    private fun label(text: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(purple, Color.rgb(60, 105, 255), cyan)
        ).apply { cornerRadius = 24f }
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 10)
            setBackgroundColor(bg)
        }

        // Compact two-tab navigation; the redundant title/header is intentionally removed.
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Color.rgb(17, 22, 39), 22f)
            setPadding(4, 4, 4, 4)
        }
        photoTab = button("▦  Фото") { showTab(0) }
        videoTab = button("▶  Видео") { showTab(1) }
        tabs.addView(photoTab, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 5 })
        tabs.addView(videoTab, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs, matchWrap())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            setPadding(12, 8, 12, 8)
        }
        widthLabel = label("Количество символов по ширине: 100", 14f)
        controls.addView(widthLabel)
        widthSeek = SeekBar(this).apply {
            max = 190 // 10..200 columns, shared by image and video conversion
            progress = 90
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    widthLabel.text = "Количество символов по ширине: ${p + 10}"
                    if (fromUser) render()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        controls.addView(widthSeek)
        controls.addView(label("Набор символов", 12f, Color.LTGRAY))
        rampSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ramps.map { it.first })
        }
        controls.addView(rampSpinner)
        customRamp = EditText(this).apply {
            hint = "Свои символы, например: .:-=+*#%@"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(12, 8, 12, 8)
            background = rounded(Color.rgb(8, 12, 24), 12f)
            visibility = View.GONE
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        controls.addView(customRamp, matchWrap())
        rampSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                customRamp.visibility = if (ramps[position].second == "CUSTOM") View.VISIBLE else View.GONE
                render()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        invert = Switch(this).apply {
            text = "Инвертировать яркость"
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
            setOnCheckedChangeListener { _, _ -> render() }
        }
        controls.addView(invert)
        root.addView(controls, matchWrap())

        photoPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 2, 0, 0)
        }
        photoPanel.addView(button("▣  Выбрать фото из галереи", ::chooseImage), matchWrap())
        val photoActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        photoActions.addView(button("Сохранить TXT") { saveTxt() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 5 })
        photoActions.addView(button("Копировать") {
            if (art.isNotEmpty()) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("ASCII art", art))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this@MainActivity, "Сначала выбери фото", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        photoPanel.addView(photoActions, matchWrap())
        photoPanel.addView(button("Сохранить изображение PNG", ::savePng), matchWrap())
        preview = label("Выбери фото, чтобы создать текстовую графику.", 7.5f).apply {
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.LEFT
            setTextIsSelectable(true)
            setTextColor(Color.rgb(220, 235, 255))
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(5, 9, 19), 12f)
        }
        val horizontal = HorizontalScrollView(this).apply {
            isFillViewport = false
            addView(preview, android.view.ViewGroup.LayoutParams(-2, -2))
        }
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            addView(horizontal, android.view.ViewGroup.LayoutParams(-1, -1))
            background = rounded(Color.rgb(5, 9, 19), 12f)
        }
        photoPanel.addView(vertical, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 5 })

        videoPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, 2, 0, 0)
        }
        videoPanel.addView(button("▶  Выбрать видео", ::chooseVideo), matchWrap())
        videoPanel.addView(label("Результат: MP4, 16:9, без звука. Количество символов, набор символов и инверсия применяются к видео так же, как к фото.", 14f, Color.LTGRAY).apply {
            setPadding(12, 14, 12, 14)
            background = rounded(Color.rgb(5, 9, 19), 12f)
        }, matchWrap())

        root.addView(photoPanel, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(videoPanel, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showTab(0)
    }

    private fun showTab(tab: Int) {
        activeTab = tab
        photoPanel.visibility = if (tab == 0) View.VISIBLE else View.GONE
        videoPanel.visibility = if (tab == 1) View.VISIBLE else View.GONE
        // Keep the selected tab visually distinct without changing the app's monochrome art identity.
        photoTab.alpha = if (tab == 0) 1f else 0.65f
        videoTab.alpha = if (tab == 1) 1f else 0.65f
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6; bottomMargin = 6 }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "video/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Выбери видео"), pickVideo)
    }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Выбери фото из галереи"), pickImage)
    }

    @Deprecated("Deprecated in Android API, kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        if (requestCode == pickImage) {
            try {
                contentResolver.openInputStream(uri)?.use { source = BitmapFactory.decodeStream(it) }
                render()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть изображение", Toast.LENGTH_LONG).show()
            }
        } else if (requestCode == pickVideo) {
            convertVideo(uri)
        }
    }

    private fun currentRamp(): String {
        val selected = ramps[rampSpinner.selectedItemPosition.coerceIn(ramps.indices)].second
        return if (selected == "CUSTOM") customRamp.text.toString().distinct().take(120).ifEmpty { "@#%*+=-:. " } else selected
    }

    private fun render() {
        val bmp = source ?: return
        val width = widthSeek.progress + 10
        val ramp = currentRamp()
        val ratio = bmp.height.toFloat() / bmp.width.toFloat()
        val height = max(1, (width * ratio * 0.48f).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, width, height, true)
        val out = StringBuilder(width * height + height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val c = scaled.getPixel(x, y)
                var lum = (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)).roundToInt()
                if (invert.isChecked) lum = 255 - lum
                val idx = ((255 - lum) * (ramp.length - 1) / 255.0).roundToInt().coerceIn(0, ramp.length - 1)
                out.append(ramp[idx])
            }
            out.append('\n')
        }
        art = out.toString()
        preview.text = art
        scaled.recycle()
    }

    private fun savePng() {
        if (art.isEmpty()) {
            Toast.makeText(this, "Сначала выбери фото", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val lines = art.trimEnd().split('\n')
            val maxChars = lines.maxOfOrNull { it.length } ?: 1
            val textSize = minOf(2400f / maxChars.coerceAtLeast(1), 4000f / lines.size.coerceAtLeast(1)).coerceIn(2f, 20f)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.create("monospace", Typeface.NORMAL)
                this.textSize = textSize
            }
            val cellWidth = textSize * 0.61f
            val lineHeight = textSize * 1.25f
            val width = (maxChars * cellWidth + 32).toInt().coerceIn(1, 4096)
            val height = (lines.size * lineHeight + 32).toInt().coerceIn(1, 4096)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.BLACK)
            lines.forEachIndexed { index, line -> canvas.drawText(line, 16f, 16f + textSize + index * lineHeight, paint) }
            val saved = saveToDownloads("textart_${System.currentTimeMillis()}.png", "image/png") { stream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            }
            bitmap.recycle()
            Toast.makeText(this, if (saved != null) "PNG сохранён в Pictures/TextArt Studio" else "Не удалось сохранить PNG", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось создать PNG", Toast.LENGTH_LONG).show()
        }
    }

    private fun convertVideo(uri: Uri) {
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Создание ASCII-видео")
            .setMessage("Подготовка… Видео будет без звука, 16:9, MP4.")
            .setView(progress)
            .setCancelable(false)
            .setNegativeButton("Скрыть", null)
            .create()
        dialog.show()
        Thread {
            var temp: File? = null
            try {
                temp = VideoAsciiEncoder.encode(this, uri, invert.isChecked, widthSeek.progress + 10, currentRamp()) { value ->
                    runOnUiThread { progress.progress = value }
                }
                val file = temp ?: throw IllegalStateException("Не создан MP4-файл")
                val outputUri = saveToDownloads("textart_video_${System.currentTimeMillis()}.mp4", "video/mp4") { stream ->
                    file.inputStream().use { input -> input.copyTo(stream) }
                }
                runOnUiThread {
                    dialog.dismiss()
                    Toast.makeText(this, if (outputUri != null) "MP4 сохранён в Downloads (16:9, без звука)" else "Видео создано, но не удалось сохранить в Downloads", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dialog.dismiss()
                    Toast.makeText(this, "Ошибка конвертации: ${e.localizedMessage ?: "неподдерживаемое видео"}", Toast.LENGTH_LONG).show()
                }
            } finally {
                temp?.delete()
            }
        }.start()
    }

    private fun saveToDownloads(name: String, mimeType: String, writer: (OutputStream) -> Unit): Uri? {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (mimeType == "image/png") "Pictures/TextArt Studio" else "Download/TextArt Studio")
            }
            val collection = if (mimeType == "image/png") MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = contentResolver.insert(collection, values) ?: return null
            try {
                contentResolver.openOutputStream(uri)?.use(writer) ?: throw IllegalStateException("Не удалось открыть файл")
                uri
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        } else {
            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: return null
            val file = File(dir, name)
            FileOutputStream(file).use(writer)
            Uri.fromFile(file)
        }
    }

    private fun saveTxt() {
        if (art.isEmpty()) {
            Toast.makeText(this, "Сначала выбери изображение", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = File(getExternalFilesDir(null), "textart_${System.currentTimeMillis()}.txt")
            FileOutputStream(file).use { it.write(art.toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Сохранено: ${file.name} (папка приложения)", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show()
        }
    }
}
