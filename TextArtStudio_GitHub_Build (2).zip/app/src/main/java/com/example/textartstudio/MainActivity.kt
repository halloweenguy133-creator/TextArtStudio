package com.example.textartstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val pickImage = 1001
    private var source: Bitmap? = null
    private var art = ""
    private lateinit var preview: TextView
    private lateinit var widthSeek: SeekBar
    private lateinit var widthLabel: TextView
    private lateinit var invert: Switch
    private lateinit var rampSpinner: Spinner

    private val ramps = listOf(
        "Детальная (@%#*+=-:. )" to "@%#*+=-:. ",
        "Плотная ($@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\\\|()1{}[]?-_+~<>i!lI;:,^`. )" to "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\\\|()1{}[]?-_+~<>i!lI;:,^`. ",
        "Простая (@#S%?*+;:,. )" to "@#S%?*+;:,. "
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 16)
            setBackgroundColor(Color.rgb(17, 19, 24))
        }
        fun label(text: String, size: Float = 15f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
        }
        root.addView(label("TextArt Studio", 25f))
        root.addView(label("Превращай фотографии в текстовую графику", 13f).apply {
            setTextColor(Color.LTGRAY)
        })
        val choose = Button(this).apply {
            text = "Выбрать изображение"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                startActivityForResult(intent, pickImage)
            }
        }
        root.addView(choose, matchWrap())
        widthLabel = label("Ширина: 100 символов")
        root.addView(widthLabel)
        widthSeek = SeekBar(this).apply {
            max = 190; progress = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    widthLabel.text = "Ширина: ${p + 10} символов"
                    if (fromUser) render()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(widthSeek)
        rampSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ramps.map { it.first })
            setSelection(0)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = render()
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        root.addView(rampSpinner, matchWrap())
        invert = Switch(this).apply {
            text = "Инвертировать яркость"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, _ -> render() }
        }
        root.addView(invert)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply {
            text = "Сохранить TXT"
            setOnClickListener { saveTxt() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "Копировать"
            setOnClickListener {
                if (art.isNotEmpty()) {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("ASCII art", art))
                    Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
                }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        preview = label("Выбери изображение, чтобы создать ASCII-графику.", 7.5f).apply {
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setTextIsSelectable(true)
            setTextColor(Color.rgb(220, 230, 240))
        }
        val scroll = ScrollView(this).apply { addView(preview) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 4 }

    @Deprecated("Deprecated in Android API, kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { source = BitmapFactory.decodeStream(it) }
                render()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть изображение", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun render() {
        val bmp = source ?: return
        val width = widthSeek.progress + 10
        val ramp = ramps[rampSpinner.selectedItemPosition.coerceIn(ramps.indices)] .second
        val ratio = bmp.height.toFloat() / bmp.width.toFloat()
        val height = max(1, (width * ratio * 0.48f).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, width, height, true)
        val out = StringBuilder(width * height + height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val c = scaled.getPixel(x, y)
                var lum = (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)).roundToInt()
                if (invert.isChecked) lum = 255 - lum
                val idx = ((255 - lum) * (ramp.length - 1) / 255.0).roundToInt().coerceIn(0, ramp.length - 1)
                out.append(ramp[idx])
            }
            out.append('\n')
        }
        art = out.toString()
        preview.text = art
        scaled.recycle()
    }

    private fun saveTxt() {
        if (art.isEmpty()) {
            Toast.makeText(this, "Сначала выбери изображение", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = File(getExternalFilesDir(null), "textart_${System.currentTimeMillis()}.txt")
            FileOutputStream(file).use { it.write(art.toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Сохранено: ${file.name} (папка приложения)", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show()
        }
    }
}
