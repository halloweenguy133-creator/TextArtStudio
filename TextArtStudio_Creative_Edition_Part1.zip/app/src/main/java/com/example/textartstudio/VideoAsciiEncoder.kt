package com.example.textartstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/** Converts video frames to monochrome ASCII and encodes a silent 16:9 H.264 MP4. */
internal object VideoAsciiEncoder {
    private const val W = 640
    private const val H = 360
    private const val FPS = 10
    private const val FRAME_US = 1_000_000L / FPS
    private const val RAMP = "@#%*+=-:. "

    fun encode(context: Context, uri: Uri, invert: Boolean, columns: Int, ramp: String, progress: (Int) -> Unit): File {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, uri)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            ?: throw IllegalArgumentException("Не удалось определить длительность видео")
        require(durationMs > 0) { "Видео пустое" }
        val frameCount = max(1, ((durationMs * 1000L) / FRAME_US).toInt())
        val durationUs = durationMs * 1000L
        val outFile = File(context.cacheDir, "textart_${System.currentTimeMillis()}.mp4")
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
            setInteger(MediaFormat.KEY_BIT_RATE, 1_800_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var track = -1
        var frameIndex = 0
        var inputEosQueued = false
        var outputDone = false
        val info = MediaCodec.BufferInfo()
        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            while (!outputDone) {
                if (frameIndex < frameCount) {
                    val inputIndex = encoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val pts = frameIndex * FRAME_US
                        val frame = retriever.getFrameAtTime(min(pts, max(0L, durationUs - 1)), MediaMetadataRetriever.OPTION_CLOSEST)
                        val ascii = frame?.let { makeAsciiFrame(it, invert, columns.coerceIn(10, 200), ramp.ifEmpty { RAMP }) }
                        frame?.recycle()
                        val yuv = bitmapToNv12(ascii ?: blankFrame())
                        val input = encoder.getInputBuffer(inputIndex) ?: throw IllegalStateException("Нет буфера кодировщика")
                        input.clear(); input.put(yuv)
                        encoder.queueInputBuffer(inputIndex, 0, yuv.size, pts, 0)
                        ascii?.recycle()
                        frameIndex++
                        progress((frameIndex * 90 / frameCount).coerceIn(1, 90))
                    }
                } else if (!inputEosQueued) {
                    val inputIndex = encoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        encoder.queueInputBuffer(inputIndex, 0, 0, frameCount * FRAME_US, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputEosQueued = true
                    }
                }

                var drain = true
                while (drain) {
                    val outputIndex = encoder.dequeueOutputBuffer(info, 0)
                    when {
                        outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> drain = false
                        outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (muxerStarted) throw IllegalStateException("Формат видео изменился повторно")
                            track = muxer.addTrack(encoder.outputFormat)
                            muxer.start(); muxerStarted = true
                        }
                        outputIndex >= 0 -> {
                            val buffer = encoder.getOutputBuffer(outputIndex)
                            if (buffer != null && info.size > 0 && muxerStarted &&
                                (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                buffer.position(info.offset); buffer.limit(info.offset + info.size)
                                muxer.writeSampleData(track, buffer, info)
                            }
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                            encoder.releaseOutputBuffer(outputIndex, false)
                        }
                    }
                }
            }
            progress(100)
        } catch (e: Exception) {
            outFile.delete()
            throw e
        } finally {
            try { encoder.stop() } catch (_: Exception) {}
            encoder.release()
            if (muxerStarted) try { muxer?.stop() } catch (_: Exception) {}
            muxer?.release()
            retriever.release()
        }
        return outFile
    }

    private fun makeAsciiFrame(src: Bitmap, invert: Boolean, requestedColumns: Int, ramp: String): Bitmap {
        val bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.BLACK)
        val cols = requestedColumns.coerceIn(10, 200)
        val rows = max(1, (cols * H.toFloat() / W * 0.67f).toInt())
        val cellW = W.toFloat() / cols
        val cellH = H.toFloat() / rows
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create("monospace", Typeface.BOLD)
            textSize = (cellH * 0.88f).coerceAtLeast(2f)
        }
        val sample = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
        val sampleCanvas = Canvas(sample)
        sampleCanvas.drawColor(Color.BLACK)
        val scale = min(cols.toFloat() / src.width, rows.toFloat() / src.height)
        val fitW = src.width * scale
        val fitH = src.height * scale
        val left = (cols - fitW) / 2f
        val top = (rows - fitH) / 2f
        sampleCanvas.drawBitmap(src, null, android.graphics.RectF(left, top, left + fitW, top + fitH), Paint(Paint.FILTER_BITMAP_FLAG))
        val baseline = (cellH - paint.fontMetrics.ascent - paint.fontMetrics.descent) / 2f
        for (y in 0 until rows) for (x in 0 until cols) {
            val c = sample.getPixel(x, y)
            var lum = (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)).toInt()
            if (invert) lum = 255 - lum
            val index = ((255 - lum) * (ramp.length - 1) / 255f).toInt().coerceIn(ramp.indices)
            canvas.drawText(ramp[index].toString(), x * cellW, y * cellH + baseline, paint)
        }
        sample.recycle()
        return bitmap
    }

    private fun blankFrame() = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }

    private fun bitmapToNv12(bitmap: Bitmap): ByteArray {
        val width = bitmap.width; val height = bitmap.height
        val out = ByteArray(width * height * 3 / 2)
        var yIndex = 0; var uvIndex = width * height
        for (y in 0 until height) for (x in 0 until width) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            out[yIndex++] = ((66 * r + 129 * g + 25 * b + 128 shr 8) + 16).coerceIn(0, 255).toByte()
            if (y % 2 == 0 && x % 2 == 0) {
                out[uvIndex++] = ((-38 * r - 74 * g + 112 * b + 128 shr 8) + 128).coerceIn(0, 255).toByte()
                out[uvIndex++] = ((112 * r - 94 * g - 18 * b + 128 shr 8) + 128).coerceIn(0, 255).toByte()
            }
        }
        bitmap.recycle()
        return out
    }
}
