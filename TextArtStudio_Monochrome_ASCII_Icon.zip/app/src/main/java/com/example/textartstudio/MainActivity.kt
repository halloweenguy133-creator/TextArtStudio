package com.example.textartstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val pickImage = 1001
    private var source: Bitmap? = null
    private var art = ""
    private lateinit var preview: TextView
    private lateinit var widthSeek: SeekBar
    private lateinit var widthLabel: TextView
    private lateinit var invert: Switch
    private lateinit var rampSpinner: Spinner

    private val bg = Color.rgb(12, 16, 30)
    private val panel = Color.rgb(24, 31, 53)
    private val cyan = Color.rgb(50, 205, 255)
    private val purple = Color.rgb(148, 76, 255)
    private val ramps = listOf(
        "Детальная (@%#*+=-:. )" to "@%#*+=-:. ",
        "Плотная ($@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\\\|()1{}[]?-_+~<>i!lI;:,^`. )" to "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\\\|()1{}[]?-_+~<>i!lI;:,^`. ",
        "Простая (@#S%?*+;:,. )" to "@#S%?*+;:,. "
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 12, 24)
        window.navigationBarColor = Color.rgb(9, 12, 24)
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; setStroke(1, Color.rgb(57, 74, 115)) }

    private fun label(text: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(purple, Color.rgb(60, 105, 255), cyan)
        ).apply { cornerRadius = 24f }
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 14)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 0, 4, 12)
        }
        header.addView(label("TextArt Studio", 28f).apply {
            setTextColor(Color.rgb(190, 150, 255))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        header.addView(label("Преобразуй фото в искусство из символов", 13f, Color.LTGRAY))
        root.addView(header)

        root.addView(button("▣   Выбрать фото из галереи", ::chooseImage), matchWrap())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            setPadding(14, 12, 14, 12)
        }
        widthLabel = label("Ширина: 100 символов", 15f)
        controls.addView(widthLabel)
        widthSeek = SeekBar(this).apply {
            max = 290
            progress = 90
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    widthLabel.text = "Ширина: ${p + 10} символов"
                    if (fromUser) render()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        controls.addView(widthSeek)
        rampSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ramps.map { it.first })
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = render()
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        controls.addView(label("Набор символов", 13f, Color.LTGRAY))
        controls.addView(rampSpinner)
        invert = Switch(this).apply {
            text = "Инвертировать яркость"
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
            setOnCheckedChangeListener { _, _ -> render() }
        }
        controls.addView(invert)
        root.addView(controls, matchWrap())

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(button("Сохранить TXT") { saveTxt() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
        buttons.addView(button("Копировать") {
            if (art.isNotEmpty()) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("ASCII art", art))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this@MainActivity, "Сначала выбери фото", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons, matchWrap())

        preview = label("Выбери фото из галереи, чтобы создать текстовую графику.", 7.5f).apply {
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.LEFT
            setTextIsSelectable(true)
            setTextColor(Color.rgb(220, 235, 255))
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(5, 9, 19), 12f)
        }
        // Scroll in both directions: long rows can be panned horizontally instead of being clipped.
        val horizontal = HorizontalScrollView(this).apply {
            isFillViewport = false
            addView(preview, android.view.ViewGroup.LayoutParams(-2, -2))
        }
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            addView(horizontal, android.view.ViewGroup.LayoutParams(-1, -1))
            background = rounded(Color.rgb(5, 9, 19), 12f)
            clipToPadding = false
        }
        root.addView(vertical, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 6 })
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6; bottomMargin = 6 }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Выбери фото из галереи"), pickImage)
    }

    @Deprecated("Deprecated in Android API, kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { source = BitmapFactory.decodeStream(it) }
                render()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть изображение", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun render() {
        val bmp = source ?: return
        val width = widthSeek.progress + 10
        val ramp = ramps[rampSpinner.selectedItemPosition.coerceIn(ramps.indices)].second
        val ratio = bmp.height.toFloat() / bmp.width.toFloat()
        val height = max(1, (width * ratio * 0.48f).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, width, height, true)
        val out = StringBuilder(width * height + height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val c = scaled.getPixel(x, y)
                var lum = (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)).roundToInt()
                if (invert.isChecked) lum = 255 - lum
                val idx = ((255 - lum) * (ramp.length - 1) / 255.0).roundToInt().coerceIn(0, ramp.length - 1)
                out.append(ramp[idx])
            }
            out.append('\n')
        }
        art = out.toString()
        preview.text = art
        scaled.recycle()
    }

    private fun saveTxt() {
        if (art.isEmpty()) {
            Toast.makeText(this, "Сначала выбери изображение", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = File(getExternalFilesDir(null), "textart_${System.currentTimeMillis()}.txt")
            FileOutputStream(file).use { it.write(art.toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Сохранено: ${file.name} (папка приложения)", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show()
        }
    }
}
